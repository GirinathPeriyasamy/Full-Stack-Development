from django import forms
from crudApp.models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'
        # exclude = ['sno'] for deselecting particular field